import express from "express";

import bookService from "./bookService.js";

import getProfessionalService from "./getProfessionalService.js";
import getAllCategoriesWithSubcate from "../../pro/home/getAdminMainSubCategory.js";
import getCategories from "./getAdminCategorie.js";
import getSubCateWithPagination from "../../pro/home/getSubCategoriePagination.js";
import mostPopularCategory from "./mostPopularCategory.js";

import multipart from "connect-multiparty";
import tokenVerification from "../../../middleware/token-verification/index.js";

const multipartMiddleware = multipart();

const router = express.Router();

//----------Get Pro whose give service in this category and subcategory----//
router.get("/getproservice", getProfessionalService);

//router.put("/:id",multipartMiddleware, updateCategory);
//router.delete("/:id", deleteCategory);
// Get Single Blog
//router.get("/single/:id", getSingleCategory);

//Create Service by User
router.post(
  "/bookservice",
  tokenVerification,
  multipartMiddleware,
  bookService
);

//--------Get All Admin Categories With subcategories---//
router.get("/subcategory", tokenVerification, getAllCategoriesWithSubcate);

//--------Get All Admin Categories-------//
router.get("/", tokenVerification, getCategories);

//--------Get Single Admin Category With subcategories Pagination---//
router.get("/subcategory/:id", tokenVerification, getSubCateWithPagination);

//--------Get Single Admin Category With subcategories Pagination---//
router.get("/mostpopular", tokenVerification, mostPopularCategory);

export default router;
