import { find } from "../../../helpers/index.js";

const getMainCategories = async (req, res) => {
  try {
    const faqcategories = await find("faqCategory");

    if (!faqcategories || faqcategories.length == 0) {
      return res.status(400).send({
        status: 400,
        message: "No faqCategory found",
      });
    }
    console.log(faqcategories, "faqcategories");

    let formattedCategories = faqcategories.map((cat) => ({
      name: cat.name,
      id: cat._id,
      status: cat.status,
    }));

    return res
      .status(200)
      .json({ status: 200, data: { categories: formattedCategories } });
  } catch (e) {
    console.log(e);
    return res.status(400).json({ status: 400, message: e.message });
  }
};

export default getMainCategories;
