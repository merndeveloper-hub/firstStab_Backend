// import mongoose from "mongoose";
// import schemaType from "../../types/index.js";


// const subSubCategorySchema = new mongoose.Schema({
//   categoryId: { type:  schemaType.TypeObjectId, ref: 'Category', required: true },
//   categoryName: { type: schemaType.TypeString, required: true },
//   subCategoryId: { type:  schemaType.TypeObjectId, ref: 'SubCategory', required: true },
//   subCategoryName: { type: schemaType.TypeString, required: true },
//   name: { type: schemaType.TypeString, required: true },
//   status: { type: schemaType.TypeString, enum: ['Active', 'Inactive'], default: 'Active' },
//   licenseRequired: { type: schemaType.TypeString, enum: ['No', 'Yes'], default: 'No' },
//   backgroundCheckRequired: { type: schemaType.TypeString, enum: ['No', 'Yes'], default: 'No' },
//   pros: { type: schemaType.TypeString, enum: ['Us Pros Only', 'Worldwide Pros'], default: 'Us Pros Only' },
//    created_date: {
//         type: schemaType.TypeDate,
//         default: Date.now,
//       },
// },{ timestamps: true });

// export default subSubCategorySchema;



