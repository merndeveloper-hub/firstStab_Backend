// import mongoose from "mongoose";
// import subSubCategorySchema from"./subSubCategorie-schema.js";

// const subSubCategory = mongoose.model("subSubCategory", subSubCategorySchema);

// export default subSubCategory;


